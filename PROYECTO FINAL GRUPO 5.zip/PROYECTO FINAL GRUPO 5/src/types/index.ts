export * from './destino.d';
export * from './homepage.d';

