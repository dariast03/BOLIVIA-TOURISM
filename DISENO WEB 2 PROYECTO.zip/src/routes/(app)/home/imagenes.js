export const images = [
    {
      id: 0,
      name: 'Cosmic timetraveler',
      imgurl: 'https://boliviamia.net/Images/Tourpics/atop-uyuni-11.jpg',
      attribution: 'cosmic-timetraveler-pYyOZ8q7AII-unsplash.com'
    },
    {
      id: 1,
      name: 'Cristina Gottardi',
      imgurl: 'https://boliviamia.net/Images/Tourpics/atop-uyuni-01.jpg',
      attribution: 'cristina-gottardi-CSpjU6hYo_0-unsplash.com'
    },
    {
      id: 2,
      name: 'Johannes Plenio',
      imgurl: 'https://boliviamia.net/Images/Tourpics/atop-uyuni-03.jpg',
      attribution: 'johannes-plenio-RwHv7LgeC7s-unsplash.com'
    },
    {
      id: 3,
      name: 'Jonatan Pie',
      imgurl: 'https://boliviamia.net/Images/Tourpics/atop-uyuni-04.jpg',
      attribution: 'jonatan-pie-3l3RwQdHRHg-unsplash.com'
    },
    {
      id: 4,
      name: 'Mark Harpur',
      imgurl: 'https://boliviamia.net/Images/Tourpics/atop-uyuni-08.jpg',
      attribution: 'mark-harpur-K2s_YE031CA-unsplash'
    },
    {
      id: 5,
      name: 'Pietro De Grandi',
      imgurl: 'https://boliviamia.net/Images/Tourpics/atop-uyuni-06.jpg',
      attribution: 'pietro-de-grandi-T7K4aEPoGGk-unsplash'
    },
    {
      id: 6,
      name: 'Sergey Pesterev',
      imgurl: 'https://boliviamia.net/Images/Tourpics/atop-uyuni-07.jpg',
      attribution: 'sergey-pesterev-tMvuB9se2uQ-unsplash'
    },
    {
      id: 7,
      name: 'Solo travel goals',
      imgurl: 'https://boliviamia.net/Images/Tourpics/atop-uyuni-10.jpg',
      attribution: 'solotravelgoals-7kLufxYoqWk-unsplash'
    }
  ];