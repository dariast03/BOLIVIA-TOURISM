<script>
	import '../app.postcss';
	import '../app.css';
	import { DarkMode } from 'flowbite-svelte';
</script>

<DarkMode btnClass="hidden" />
<slot />
