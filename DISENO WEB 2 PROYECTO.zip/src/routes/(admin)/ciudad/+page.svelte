<script>
	import { Heading } from 'flowbite-svelte';
</script>

<Heading>CIUDADES</Heading>
